package com.example.lecture12

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main3.*
import java.util.*

class MainActivity3 : AppCompatActivity() {
    lateinit var tts: TextToSpeech
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        //one
        val b1=findViewById(R.id.button1) as Button
        val t1=findViewById(R.id.text1) as TextView

        //two
        val b2=findViewById(R.id.button2) as Button
        val t2=findViewById(R.id.text2) as TextView

        //three
        val b3=findViewById(R.id.button3) as Button
        val t3=findViewById(R.id.text3) as TextView

        //four
        val b4=findViewById(R.id.button4) as Button
        val t4=findViewById(R.id.text4) as TextView

        //five
        val b5=findViewById(R.id.button5) as Button
        val t5=findViewById(R.id.text5) as TextView

        //one
        button1.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(text1.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }


        //two
        button2.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(text2.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }

        //three
        button3.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(text3.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }

        //four
        button4.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(text4.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }

        //five
        button5.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(text5.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }

    }

}