package com.example.lecture12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main3.*
import java.util.*

class MainActivity2 : AppCompatActivity() {

    lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val b1=findViewById(R.id.b_apple) as Button
        val t1=findViewById(R.id.apple) as TextView

        val b2=findViewById(R.id.b_orange) as Button
        val t2=findViewById(R.id.orange) as TextView

        val b3=findViewById(R.id.b_banana) as Button
        val t3=findViewById(R.id.banana) as TextView

        val b4=findViewById(R.id.b_apple) as Button
        val t4=findViewById(R.id.apple) as TextView

        val b5=findViewById(R.id.b_apple) as Button
        val t5=findViewById(R.id.apple) as TextView


        //apple
        b_apple.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(apple.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }


        //orange
        b_orange.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(orange.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }


        //banana
        b_banana.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(banana.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }



        //grapes
        b_grapes.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(grapes.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }


        //mango
        b_mango.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it == TextToSpeech.SUCCESS)
                {
                    tts.language= Locale.UK
                    tts.setSpeechRate(1.05f)
                    tts.speak(mango.text.toString(), TextToSpeech.QUEUE_ADD, null)
                }

            })
        }

    }
}